
window.onload=function(){
	var body=document.getElementsByTagName("body")[0],
		a=body.background;
	if (a!=="")
	{
		
		var bu=document.createElement("div")
			bu.id="bu";
		var bu1=document.createElement("div")
			bu1.id="bu1";
		body.appendChild(bu);
		body.appendChild(bu1);
	}



}